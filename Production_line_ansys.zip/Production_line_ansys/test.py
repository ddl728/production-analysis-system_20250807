
i = 0
a = 1

while a < 10:
    if a % 2 == 1:
        print("奇数")
        a += 1
    else:
        print("偶数")
        a += 1

