import math
import sys
import networkx as nx
import pandas as pd
from PyQt5.QtCore import Qt, QLineF, QPointF
from PyQt5.QtGui import QColor, QFont, QPainterPath, QPolygonF, QPen, QBrush
from PyQt5.QtGui import QImage, QPainter
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QPushButton, QVBoxLayout, QHBoxLayout, QWidget, QCheckBox, QComboBox, QLabel,
    QColorDialog, QSpinBox,
    QGraphicsView, QGraphicsScene, QGraphicsEllipseItem, QGraphicsLineItem,
    QGraphicsTextItem, QGraphicsPathItem,
    QGraphicsPolygonItem,
    QGroupBox, QScrollArea, QTableWidget, QTableWidgetItem, QHeaderView, QLineEdit
)
from PyQt5.QtWidgets import QFileDialog, QMessageBox
from matplotlib import cm
from matplotlib import pyplot as plt
from networkx.algorithms.community import greedy_modularity_communities
from networkx.algorithms.community.label_propagation import label_propagation_communities
from networkx.algorithms.community.louvain import louvain_communities
from graph_layout import shell_layout, concentric_layout


class GraphVisualizer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.ctrl_pressed = None
        self.setWindowTitle("可交互式产线参数关联关系分析系统")
        # 设置全局字体样式
        self.setup_fonts()
        # 初始化图数据结构
        self.graph = None
        self.name_to_id = {}  # 中文名称 → 编号
        self.id_to_name = {}  # 编号 → 中文名称
        # 颜色常量
        self.default_node_color = "#87CEEB"
        self.default_edge_color = "#999999"

        self.cached_pos = None
        self.last_layout_func = None
        self.highlight_node = None

        self.node_color = QColor("skyblue")
        self.edge_width = 1
        self.edge_color = QColor("gray")
        self.node_shape = 'o'
        self.node_size = 20
        self.edge_style = "无箭头-直线"

        self.shape_map = {
            "圆形": 'o',
            "三角形": 't',
            "菱形": 'd',
            "五边形": 'p',
            "五角星形": '*'
        }
        self.layout_map = {
            "Spring": nx.spring_layout,
            "Ring": nx.circular_layout,
            "Kamada-Kawai": nx.kamada_kawai_layout,
            "Shell": shell_layout,
            "Spectral": nx.spectral_layout,
            "random": nx.random_layout,
            "Circular": concentric_layout,
        }

        self.scene = QGraphicsScene()
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHint(QPainter.Antialiasing)
        self.view.setAlignment(Qt.AlignTop | Qt.AlignLeft)
        self.view.setDragMode(QGraphicsView.ScrollHandDrag)
        self.view.setTransformationAnchor(QGraphicsView.AnchorUnderMouse)
        self.view.setResizeAnchor(QGraphicsView.AnchorUnderMouse)
        self.view.setInteractive(True)
        self.view.setMouseTracking(True)
        self.view.viewport().installEventFilter(self)

        self._dragging_node = None
        self._drag_offset = QPointF()

        self.gexf_button = QPushButton("导入 GEXF 文件")
        self.gexf_button.setFont(self.bold_font)
        self.gexf_button.clicked.connect(self.load_gexf_graph)
        self.csv_button = QPushButton("导入 CSV 文件")
        self.csv_button.setFont(self.bold_font)
        self.csv_button.clicked.connect(self.load_csv_graph)

        self.node_color_btn = QPushButton("节点颜色")
        self.node_color_btn.setFont(self.bold_font)
        self.node_color_btn.clicked.connect(self.change_node_color)

        self.shape_combo = QComboBox()
        self.shape_combo.setFont(self.bold_font)
        self.shape_combo.addItems(list(self.shape_map.keys()))
        self.shape_combo.currentTextChanged.connect(self.change_node_shape)

        self.node_size_spin = QSpinBox()
        self.node_size_spin.setFont(self.bold_font)
        self.node_size_spin.setRange(5, 100)
        self.node_size_spin.setValue(self.node_size)
        self.node_size_spin.valueChanged.connect(self.change_node_size)

        self.save_button = QPushButton("保存结果")
        self.save_button.setFont(self.bold_font)
        self.save_button.clicked.connect(self.save_graph_as_png)

        # 创建带粗体字体的标签
        node_shape_label = QLabel("节点形状：")
        node_shape_label.setFont(self.bold_font)
        node_size_label = QLabel("节点大小：")
        node_size_label.setFont(self.bold_font)

        node_group_layout = QVBoxLayout()
        node_group_layout.addWidget(node_shape_label)
        node_group_layout.addWidget(self.shape_combo)
        node_group_layout.addWidget(node_size_label)
        node_group_layout.addWidget(self.node_size_spin)
        node_group_layout.addWidget(self.node_color_btn)

        node_group = QGroupBox("节点设置")
        self.gexf_button.setFont(self.bold_font)
        node_group.setLayout(node_group_layout)

        self.edge_width_spin = QSpinBox()
        self.edge_width_spin.setFont(self.bold_font)
        self.edge_width_spin.setRange(1, 10)
        self.edge_width_spin.setValue(self.edge_width)
        self.edge_width_spin.valueChanged.connect(self.change_edge_width)

        self.edge_color_btn = QPushButton("边颜色")
        self.gexf_button.setFont(self.bold_font)
        self.edge_color_btn.clicked.connect(self.change_edge_color)

        self.edge_style_combo = QComboBox()
        self.edge_style_combo.setFont(self.bold_font)
        self.edge_style_combo.addItems(
            ["无箭头-直线", "无箭头-虚线", "无箭头-曲线", "带箭头-直线", "带箭头-虚线", "带箭头-曲线"]
        )
        self.edge_style_combo.currentTextChanged.connect(self.change_edge_style)

        # 创建带粗体字体的标签
        edge_style_label = QLabel("边样式：")
        edge_style_label.setFont(self.bold_font)
        edge_width_label = QLabel("边粗细：")
        edge_width_label.setFont(self.bold_font)

        edge_group_layout = QVBoxLayout()
        edge_group_layout.addWidget(edge_style_label)
        edge_group_layout.addWidget(self.edge_style_combo)
        edge_group_layout.addWidget(edge_width_label)
        edge_group_layout.addWidget(self.edge_width_spin)
        edge_group_layout.addWidget(self.edge_color_btn)

        edge_group = QGroupBox("边设置")
        edge_group.setFont(self.bold_font)
        edge_group.setLayout(edge_group_layout)

        self.weight_checkbox = QCheckBox("显示边权重")
        self.weight_checkbox.setFont(self.bold_font)
        self.weight_checkbox.setChecked(True)
        self.label_checkbox = QCheckBox("显示节点标签")
        self.label_checkbox.setFont(self.bold_font)
        self.label_checkbox.setChecked(True)

        self.layout_combo = QComboBox()
        self.layout_combo.setFont(self.bold_font)
        self.layout_combo.addItems(list(self.layout_map.keys()))
        self.layout_combo.currentTextChanged.connect(self.layout_changed)
        """
        模块化划分区域
        """
        # 模块化设置区域
        self.module_algo_combo = QComboBox()
        self.module_algo_combo.setFont(self.bold_font)
        self.module_algo_combo.addItems(["greedy", "label_propagation", "louvain"])
        self.module_algo_combo.setToolTip("选择模块化算法")

        self.module_spinbox = QSpinBox()
        self.module_spinbox.setFont(self.bold_font)
        self.module_spinbox.setRange(2, 10)
        self.module_spinbox.setValue(4)

        self.modularize_btn = QPushButton("模块化分析")
        self.modularize_btn.setFont(self.bold_font)
        self.clear_community_btn = QPushButton("取消模块化")
        self.clear_community_btn.setFont(self.bold_font)

        self.modularize_btn.clicked.connect(self.apply_community_coloring)
        self.clear_community_btn.clicked.connect(self.clear_communities)

        # 创建带粗体字体的标签
        module_algo_label = QLabel("模块化算法：")
        module_algo_label.setFont(self.bold_font)
        module_count_label = QLabel("区域数：")
        module_count_label.setFont(self.bold_font)

        module_group_layout = QVBoxLayout()
        module_group_layout.addWidget(module_algo_label)
        module_group_layout.addWidget(self.module_algo_combo)
        module_group_layout.addWidget(module_count_label)
        module_group_layout.addWidget(self.module_spinbox)
        module_group_layout.addWidget(self.modularize_btn)
        module_group_layout.addWidget(self.clear_community_btn)

        module_group = QGroupBox("模块化")
        module_group.setFont(self.bold_font)
        module_group.setLayout(module_group_layout)
        self.module_algo_combo.currentTextChanged.connect(self.on_module_algo_changed)

        # 创建带粗体字体的标签
        layout_label = QLabel("布局方式：")
        layout_label.setFont(self.bold_font)

        control_layout = QVBoxLayout()
        control_layout.setAlignment(Qt.AlignTop)
        control_layout.addWidget(self.gexf_button)
        control_layout.addWidget(self.csv_button)
        control_layout.addWidget(node_group)
        control_layout.addWidget(edge_group)
        control_layout.addWidget(layout_label)
        control_layout.addWidget(self.layout_combo)
        control_layout.addWidget(self.weight_checkbox)
        control_layout.addWidget(self.label_checkbox)
        control_layout.addWidget(module_group)

        control_widget = QWidget()
        control_widget.setLayout(control_layout)
        control_layout.addStretch()
        control_layout.addWidget(self.save_button)

        scroll_area = QScrollArea()
        scroll_area.setWidgetResizable(True)
        scroll_area.setWidget(control_widget)
        scroll_area.setFixedWidth(250)

        self.run_button = QPushButton("运行")
        self.run_button.setFont(self.bold_font)
        self.run_button.clicked.connect(self.draw_graph)

        # 创建带粗体字体的标签
        visualization_label = QLabel("图结构可视化结果：")
        visualization_label.setFont(self.bold_font)

        right_layout = QVBoxLayout()
        right_layout.addWidget(visualization_label)
        right_layout.addWidget(self.run_button)
        right_layout.addWidget(self.view)

        self.search_box = QLineEdit()
        self.search_box.setFont(self.bold_font)
        self.search_box.setPlaceholderText("请输入节点序号:")
        self.search_box.returnPressed.connect(self.search_node)

        self.node_info = QLabel("节点：")
        self.node_info.setFont(self.bold_font)

        self.edge_info = QLabel("边：")
        self.edge_info.setFont(self.bold_font)

        self.table = QTableWidget(0, 4)
        self.table.setFont(self.bold_font)
        self.table.setHorizontalHeaderLabels(["序号", "节点名称", "父节点序号", "子节点序号"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.cellClicked.connect(self.on_table_cell_clicked)

        # 创建带粗体字体的标签
        node_properties_label = QLabel("节点属性")
        node_properties_label.setFont(self.bold_font)

        analysis_layout = QVBoxLayout()
        for widget in [self.search_box, self.node_info, self.edge_info, node_properties_label, self.table]:
            analysis_layout.addWidget(widget)

        analysis_widget = QWidget()
        analysis_widget.setLayout(analysis_layout)
        analysis_widget.setFixedWidth(300)

        main_layout = QHBoxLayout()
        main_layout.addWidget(scroll_area)
        main_layout.addLayout(right_layout)
        main_layout.addWidget(analysis_widget)

        central_widget = QWidget()
        central_widget.setLayout(main_layout)
        self.setCentralWidget(central_widget)
    """
    按照用户指定的模块数将节点划分模块，并给每个模块分配不同颜色
    """
    def apply_modular_layout(self):
        if not self.graph or len(self.graph.nodes) == 0:
            return
        n_modules = self.module_spinbox.value()
        nodes = list(self.graph.nodes)
        chunk_size = len(nodes) // n_modules

        # 构造颜色列表
        colors = [QColor.fromHsv((i * 360) // n_modules, 255, 200) for i in range(n_modules)]

        # 节点模块划分
        for i, node in enumerate(nodes):
            group = min(i // chunk_size, n_modules - 1)
            self.graph.nodes[node]["color"] = colors[group]

        # 边模块划分（依据 source 节点）
        for u, v in self.graph.edges():
            group = min(nodes.index(u) // chunk_size, n_modules - 1)
            self.graph.edges[u, v]["color"] = colors[group]
        self.draw_graph()

    """实现图形视图中节点的鼠标拖拽功能（拖动节点进行手动布局）"""
    def eventFilter(self, source, event):
        if source is self.view.viewport():
            if event.type() == event.MouseButtonPress:
                pos = self.view.mapToScene(event.pos())
                item = self.scene.itemAt(pos, self.view.transform())
                if isinstance(item, QGraphicsEllipseItem):
                    self._dragging_node = item
                    self._drag_offset = item.pos() - pos
            elif event.type() == event.MouseMove:
                if self._dragging_node:
                    pos = self.view.mapToScene(event.pos())
                    self._dragging_node.setPos(pos + self._drag_offset)
            elif event.type() == event.MouseButtonRelease:
                self._dragging_node = None
        return super().eventFilter(source, event)

    """按下 Ctrl 键时启用图的拖动模式"""
    def keyPressEvent(self, event):
        if event.key() == Qt.Key_Control:
            self.ctrl_pressed = True
            self.view.setDragMode(QGraphicsView.ScrollHandDrag)

    """释放 Ctrl 键时取消图的拖动模式"""
    def keyReleaseEvent(self, event):
        if event.key() == Qt.Key_Control:
            self.ctrl_pressed = False
            self.view.setDragMode(QGraphicsView.NoDrag)

    """通过文件选择对话框导入 GEXF 格式图文件并加载至 NetworkX 图对象中"""
    def load_gexf_graph(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open GEXF File", "", "GEXF Files (*.gexf)")
        if not file_path:
            return
        self.graph = nx.read_gexf(file_path)
        self.draw_graph()

    """通过文件选择对话框导入 CSV 邻接矩阵，并转换为 NetworkX 图对象"""
    def load_csv_graph(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Open CSV File", "", "CSV Files (*.csv)")
        if not file_path:
            return

        df = pd.read_csv(file_path, index_col=0)
        upstream_names = df.index.tolist()
        downstream_names = df.columns.tolist()

        # 映射中文名称为编号，从 1 开始
        all_names = list(dict.fromkeys(upstream_names + downstream_names))  # 保持顺序去重
        # all_names = list(dict.fromkeys(df.index.tolist() + df.columns.tolist()))  # 保持顺序去重
        self.name_to_id = {name: str(i + 1) for i, name in enumerate(all_names)}
        self.id_to_name = {v: k for k, v in self.name_to_id.items()}

        self.graph = nx.DiGraph()
        # self.graph = nx.from_pandas_adjacency(df)
        self.name_to_id.clear()
        self.id_to_name.clear()
        # 提取所有不重复节点名称（保持顺序）
        all_names = []
        for name in list(df.index) + list(df.columns):
            if pd.notna(name) and name not in all_names:
                all_names.append(name)
        # 重新编号：从 1 开始
        self.name_to_id = {name: str(i + 1) for i, name in enumerate(all_names)}
        self.id_to_name = {v: k for k, v in self.name_to_id.items()}
        # 建图
        # for i, src_name in enumerate(df.index):
        #     for j, dst_name in enumerate(df.columns):
        #         weight = df.iat[i, j]
        #         if weight != 0:
        #             src_id = self.name_to_id.get(src_name)
        #             dst_id = self.name_to_id.get(dst_name)
        #             if src_id and dst_id:
        #                 self.graph.add_edge(src_id, dst_id, weight=weight)
        for i, src_name in enumerate(df.index):
            for j, dst_name in enumerate(df.columns):
                weight = df.iat[i, j]
                if weight != 0:
                    src_id = self.name_to_id.get(src_name)
                    dst_id = self.name_to_id.get(dst_name)
                    if src_id and dst_id:
                        self.graph.add_edge(src_id, dst_id, weight=weight)
        self.draw_graph()
        self.populate_node_table()

    """
    根据指定的模块化算法计算社区划分，返回节点对应的模块编号。
    参数:
        method: 模块划分方法，可选 'greedy', 'manual'
        module_count: 模块数量（manual模式下有效）
    返回:
        dict: 节点编号 → 模块编号
    """
    def compute_communities(self, method="greedy", module_count=3):
        import networkx.algorithms.community as nx_comm

        if self.graph is None:
            return {}

        if method == "greedy":
            communities = nx_comm.greedy_modularity_communities(self.graph)
            node_to_module = {}
            for i, community in enumerate(communities):
                for node in community:
                    node_to_module[node] = i
            return node_to_module

        elif method == "manual":
            node_list = list(self.graph.nodes())
            module_size = len(node_list) // module_count
            node_to_module = {}
            for i, node in enumerate(node_list):
                module_id = i // module_size
                module_id = min(module_id, module_count - 1)
                node_to_module[node] = module_id
            return node_to_module

        else:
            return {}

    """
    根据当前图的结构和参数设置在 QGraphicsScene 上绘制图。
    支持节点/边样式、布局选择、模块上色、权重显示、标签显示等。
    """

    def draw_graph(self):
        self.scene.clear()
        if self.graph is None:
            return

        QApplication.processEvents()

        layout_func = self.layout_map.get(self.layout_combo.currentText(), nx.spring_layout)
        if self.cached_pos is None or layout_func != self.last_layout_func:
            self.cached_pos = layout_func(self.graph)
            self.last_layout_func = layout_func

        pos = self.cached_pos
        nodes = list(self.graph.nodes)
        edges = list(self.graph.edges)

        self.node_info.setText(f"节点：{len(nodes)} 个")
        self.edge_info.setText(f"边：{len(edges)} 条")

        show_weights = self.weight_checkbox.isChecked()
        show_labels = self.label_checkbox.isChecked()
        scale = 400

        # 模块化颜色字典
        communities_dict = getattr(self, 'communities_dict', {})
        module_colors = {}
        if communities_dict:
            unique_modules = sorted(set(communities_dict.values()))
            colormap = cm.get_cmap('tab20', len(unique_modules))
            for idx, module in enumerate(unique_modules):
                color = QColor.fromRgbF(*colormap(idx)[:3])
                module_colors[module] = color

        # 绘制边
        for u, v in self.graph.edges:
            x1, y1 = pos[u][0] * scale, pos[u][1] * scale
            x2, y2 = pos[v][0] * scale, pos[v][1] * scale

            # 计算节点大小
            node_size = self.node_size_spin.value()
            node_radius = node_size / 2

            # 计算边的实际起点和终点（从节点边框开始和结束）
            dx = x2 - x1
            dy = y2 - y1
            distance = math.sqrt(dx * dx + dy * dy)

            if distance > 0:
                unit_dx = dx / distance
                unit_dy = dy / distance

                # 调整起点和终点到节点边框
                edge_start_x = x1 + unit_dx * node_radius
                edge_start_y = y1 + unit_dy * node_radius
                edge_end_x = x2 - unit_dx * node_radius
                edge_end_y = y2 - unit_dy * node_radius
            else:
                edge_start_x, edge_start_y = x1, y1
                edge_end_x, edge_end_y = x2, y2

            line = QLineF(edge_start_x, edge_start_y, edge_end_x, edge_end_y)

            pen = QPen()
            pen.setWidth(self.edge_width_spin.value())

            # 使用模块颜色
            edge_color = self.graph.edges[u, v].get("color", self.edge_color)
            if communities_dict:
                module_id = communities_dict.get(u, 0)
                edge_color = module_colors.get(module_id, self.edge_color)
            pen.setColor(edge_color)

            style = self.edge_style_combo.currentText()

            # 设置线条样式
            if "虚线" in style:
                pen.setStyle(Qt.DashLine)
            else:
                pen.setStyle(Qt.SolidLine)

            # 绘制不同类型的边
            if "曲线" in style:
                # 绘制曲线
                path = QPainterPath(QPointF(edge_start_x, edge_start_y))
                dx_curve = (edge_end_x - edge_start_x) * 0.2
                dy_curve = (edge_end_y - edge_start_y) * 0.2
                ctrl = QPointF((edge_start_x + edge_end_x) / 2 - dy_curve,
                               (edge_start_y + edge_end_y) / 2 + dx_curve)
                path.quadTo(ctrl, QPointF(edge_end_x, edge_end_y))
                item = QGraphicsPathItem(path)
                item.setPen(pen)
                self.scene.addItem(item)
            else:
                # 绘制直线
                item = QGraphicsLineItem(line)
                item.setPen(pen)
                self.scene.addItem(item)

            # 只有当样式包含"带箭头"时才绘制箭头
            if "带箭头" in style:
                if distance > 0:
                    # 箭头指向节点边框上的点
                    arrow_target_x = x2 - unit_dx * node_radius
                    arrow_target_y = y2 - unit_dy * node_radius

                    # 计算箭头的角度
                    angle = math.atan2(dy, dx)
                    arrow_size = 10

                    # 箭头的两个侧翼点
                    arrow_p1 = QPointF(arrow_target_x, arrow_target_y) - QPointF(
                        math.cos(angle - math.pi / 6) * arrow_size,
                        math.sin(angle - math.pi / 6) * arrow_size
                    )
                    arrow_p2 = QPointF(arrow_target_x, arrow_target_y) - QPointF(
                        math.cos(angle + math.pi / 6) * arrow_size,
                        math.sin(angle + math.pi / 6) * arrow_size
                    )

                    # 创建箭头多边形
                    arrow_head = QPolygonF([QPointF(arrow_target_x, arrow_target_y), arrow_p1, arrow_p2])
                    arrow_item = QGraphicsPolygonItem(arrow_head)
                    arrow_item.setBrush(QBrush(pen.color()))
                    arrow_item.setPen(pen)
                    self.scene.addItem(arrow_item)

            # 显示权重
            if show_weights:
                weight = self.graph[u][v].get('weight', '')
                if weight != '':
                    text = QGraphicsTextItem(str(weight))
                    text.setFont(QFont("Arial", 10))
                    text.setDefaultTextColor(Qt.darkGray)
                    text.setPos((edge_start_x + edge_end_x) / 2, (edge_start_y + edge_end_y) / 2)
                    self.scene.addItem(text)

        # 绘制节点
        for node in self.graph.nodes:
            x, y = pos[node][0] * scale, pos[node][1] * scale
            size = self.node_size_spin.value()
            shape_code = self.shape_map.get(self.shape_combo.currentText(), 'o')

            # 颜色选择（优先高亮颜色，然后是模块颜色）
            node_color = self.graph.nodes[node].get("color", self.node_color)

            # 检查是否为高亮节点
            is_highlight = (self.highlight_node == node)

            if is_highlight:
                # 高亮节点使用鲜艳颜色（红色）
                node_color = QColor(255, 0, 0)  # 红色高亮
            elif communities_dict:
                # 模块化颜色
                module_id = communities_dict.get(node, 0)
                node_color = module_colors.get(module_id, self.node_color)

            brush = QBrush(node_color)
            pen = QPen(Qt.black)

            # 高亮节点使用更粗的边框
            if is_highlight:
                pen.setWidth(3)
                pen.setColor(QColor(255, 165, 0))  # 橙色边框
            else:
                pen.setWidth(1)

            if shape_code == 'o':  # 圆形
                # 高亮节点使用稍大的尺寸
                node_size = size * 1.3 if is_highlight else size
                ellipse = QGraphicsEllipseItem(x - node_size / 2, y - node_size / 2, node_size, node_size)
                ellipse.setBrush(brush)
                ellipse.setPen(pen)
                self.scene.addItem(ellipse)
                ellipse.setZValue(2 if is_highlight else 1)  # 高亮节点置于顶层
            elif shape_code == 't':  # 三角形
                node_size = size * 1.3 if is_highlight else size
                triangle = QPolygonF([
                    QPointF(x, y - node_size / 2),
                    QPointF(x - node_size / 2, y + node_size / 2),
                    QPointF(x + node_size / 2, y + node_size / 2)
                ])
                item = QGraphicsPolygonItem(triangle)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(2 if is_highlight else 1)
            elif shape_code == 'd':  # 菱形
                node_size = size * 1.3 if is_highlight else size
                diamond = QPolygonF([
                    QPointF(x, y - node_size / 2),
                    QPointF(x - node_size / 2, y),
                    QPointF(x, y + node_size / 2),
                    QPointF(x + node_size / 2, y)
                ])
                item = QGraphicsPolygonItem(diamond)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(2 if is_highlight else 1)
            elif shape_code == 'p':  # 五边形
                node_size = size * 1.3 if is_highlight else size
                points = []
                for i in range(5):
                    angle_deg = 72 * i - 90
                    angle_rad = math.radians(angle_deg)
                    points.append(QPointF(x + node_size * math.cos(angle_rad) / 2,
                                          y + node_size * math.sin(angle_rad) / 2))
                polygon = QPolygonF(points)
                item = QGraphicsPolygonItem(polygon)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(2 if is_highlight else 1)
            elif shape_code == '*':  # 星形（五角星）
                node_size = size * 1.3 if is_highlight else size
                points = []
                for i in range(10):
                    angle_deg = 36 * i - 90
                    r = node_size / 2 if i % 2 == 0 else node_size / 4
                    angle_rad = math.radians(angle_deg)
                    points.append(QPointF(x + r * math.cos(angle_rad),
                                          y + r * math.sin(angle_rad)))
                star = QPolygonF(points)
                item = QGraphicsPolygonItem(star)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(2 if is_highlight else 1)

            # 显示标签
            if show_labels:
                label = self.id_to_name.get(node, str(node))
                text = QGraphicsTextItem(label)
                text.setFont(self.label_font)
                text.setFont(QFont("Arial", 10))

                # 高亮节点的标签使用不同颜色
                if is_highlight:
                    text.setDefaultTextColor(QColor(255, 0, 0))  # 红色标签
                else:
                    text.setDefaultTextColor(Qt.black)

                text.setPos(x + size / 2 + 4, y - size / 2)
                self.scene.addItem(text)
                text.setZValue(2 if is_highlight else 1)

    """
    draw_graph()，实现模块化的功能，而高亮序号节点无法实现
    """
    def draw_graph_show_layout(self):
        self.scene.clear()
        if self.graph is None:
            return

        QApplication.processEvents()

        layout_func = self.layout_map.get(self.layout_combo.currentText(), nx.spring_layout)
        if self.cached_pos is None or layout_func != self.last_layout_func:
            self.cached_pos = layout_func(self.graph)
            self.last_layout_func = layout_func

        pos = self.cached_pos
        nodes = list(self.graph.nodes)
        edges = list(self.graph.edges)

        self.node_info.setText(f"节点：{len(nodes)} 个")
        self.edge_info.setText(f"边：{len(edges)} 条")

        show_weights = self.weight_checkbox.isChecked()
        show_labels = self.label_checkbox.isChecked()
        scale = 400

        # 模块化颜色字典
        communities_dict = getattr(self, 'communities_dict', {})
        module_colors = {}
        if communities_dict:
            unique_modules = sorted(set(communities_dict.values()))
            colormap = cm.get_cmap('tab20', len(unique_modules))
            # colormap = colormaps.get_cmap('tab20', len(unique_modules))
            for idx, module in enumerate(unique_modules):
                color = QColor.fromRgbF(*colormap(idx)[:3])
                module_colors[module] = color

        # 绘制边
        for u, v in self.graph.edges:
            x1, y1 = pos[u][0] * scale, pos[u][1] * scale
            x2, y2 = pos[v][0] * scale, pos[v][1] * scale
            line = QLineF(x1, y1, x2, y2)

            pen = QPen()
            pen.setWidth(self.edge_width_spin.value())

            # 使用模块颜色
            edge_color = self.graph.edges[u, v].get("color", self.edge_color)
            if communities_dict:
                module_id = communities_dict.get(u, 0)
                edge_color = module_colors.get(module_id, self.edge_color)
            pen.setColor(edge_color)

            style = self.edge_style_combo.currentText()

            if "虚线" in style:
                pen.setStyle(Qt.DashLine)
            elif "曲线" in style:
                path = QPainterPath(QPointF(x1, y1))
                dx = (x2 - x1) * 0.2
                dy = (y2 - y1) * 0.2
                ctrl = QPointF((x1 + x2) / 2 - dy, (y1 + y2) / 2 + dx)
                path.quadTo(ctrl, QPointF(x2, y2))
                item = QGraphicsPathItem(path)
                item.setPen(pen)
                self.scene.addItem(item)
            else:
                item = QGraphicsLineItem(line)
                item.setPen(pen)
                self.scene.addItem(item)

            # 箭头
            if "带箭头" in style:
                angle = math.atan2(y2 - y1, x2 - x1)
                arrow_size = 10
                arrow_p1 = QPointF(x2, y2) - QPointF(math.cos(angle - math.pi / 6) * arrow_size,
                                                     math.sin(angle - math.pi / 6) * arrow_size)
                arrow_p2 = QPointF(x2, y2) - QPointF(math.cos(angle + math.pi / 6) * arrow_size,
                                                     math.sin(angle + math.pi / 6) * arrow_size)
                arrow_head = QPolygonF([QPointF(x2, y2), arrow_p1, arrow_p2])
                arrow_item = QGraphicsPolygonItem(arrow_head)
                arrow_item.setBrush(QBrush(pen.color()))
                arrow_item.setPen(pen)
                self.scene.addItem(arrow_item)

            if show_weights:
                weight = self.graph[u][v].get('weight', '')
                if weight != '':
                    text = QGraphicsTextItem(str(weight))
                    text.setFont(QFont("Arial", 10))
                    text.setDefaultTextColor(Qt.darkGray)
                    text.setPos((x1 + x2) / 2, (y1 + y2) / 2)
                    self.scene.addItem(text)

        # 绘制节点
        for node in self.graph.nodes:
            x, y = pos[node][0] * scale, pos[node][1] * scale
            size = self.node_size_spin.value()
            shape_code = self.shape_map.get(self.shape_combo.currentText(), 'o')

            # 颜色选择（优先模块颜色）
            node_color = self.graph.nodes[node].get("color", self.node_color)
            if communities_dict:
                module_id = communities_dict.get(node, 0)
                node_color = module_colors.get(module_id, self.node_color)

            brush = QBrush(node_color)
            pen = QPen(Qt.black)
            pen.setWidth(1)

            if shape_code == 'o':  # 圆形
                ellipse = QGraphicsEllipseItem(x - size / 2, y - size / 2, size, size)
                ellipse.setBrush(brush)
                ellipse.setPen(pen)
                self.scene.addItem(ellipse)
                ellipse.setZValue(1)
            elif shape_code == 't':  # 三角形
                triangle = QPolygonF([
                    QPointF(x, y - size / 2),
                    QPointF(x - size / 2, y + size / 2),
                    QPointF(x + size / 2, y + size / 2)
                ])
                item = QGraphicsPolygonItem(triangle)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(1)
            elif shape_code == 'd':  # 菱形
                diamond = QPolygonF([
                    QPointF(x, y - size / 2),
                    QPointF(x - size / 2, y),
                    QPointF(x, y + size / 2),
                    QPointF(x + size / 2, y)
                ])
                item = QGraphicsPolygonItem(diamond)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(1)
            elif shape_code == 'p':  # 五边形
                points = []
                for i in range(5):
                    angle_deg = 72 * i - 90
                    angle_rad = math.radians(angle_deg)
                    points.append(QPointF(x + size * math.cos(angle_rad) / 2,
                                          y + size * math.sin(angle_rad) / 2))
                polygon = QPolygonF(points)
                item = QGraphicsPolygonItem(polygon)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(1)
            elif shape_code == '*':  # 星形（五角星）
                points = []
                for i in range(10):
                    angle_deg = 36 * i - 90
                    r = size / 2 if i % 2 == 0 else size / 4
                    angle_rad = math.radians(angle_deg)
                    points.append(QPointF(x + r * math.cos(angle_rad),
                                          y + r * math.sin(angle_rad)))
                star = QPolygonF(points)
                item = QGraphicsPolygonItem(star)
                item.setBrush(brush)
                item.setPen(pen)
                self.scene.addItem(item)
                item.setZValue(1)

            # 显示标签
            if show_labels:
                label = self.id_to_name.get(node, str(node))
                text = QGraphicsTextItem(label)
                text.setFont(QFont("Arial", 10))
                text.setDefaultTextColor(Qt.black)
                text.setPos(x + size / 2 + 4, y - size / 2)
                self.scene.addItem(text)

    # 颜色、大小、形状、样式控制逻辑
    def change_node_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.node_color = color
            self.draw_graph()

    def change_edge_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.edge_color = color
            self.draw_graph()

    def change_node_shape(self, text):
        self.node_shape = self.shape_map.get(text, 'o')
        self.draw_graph()

    def change_node_size(self, value):
        self.node_size = value
        self.draw_graph()

    def change_edge_style(self, style):
        self.edge_style = style
        self.draw_graph()

    def change_edge_width(self, value):
        self.edge_width = value
        self.draw_graph()

    # 当布局切换时，清除缓存并重新绘图
    def layout_changed(self, text):
        self.cached_pos = None
        self.draw_graph()

    def on_table_cell_clicked(self, row, column):
        """当用户点击属性表中的某个单元格时，自动高亮对应的图中节点"""
        if self.table.item(row, 0):  # 确保单元格存在
            node_id = self.table.item(row, 0).text()
            if node_id in self.graph.nodes:
                self.highlight_node = node_id
                if hasattr(self, 'statusBar'):
                    self.statusBar().showMessage(f"选中了表格中的节点 {node_id}", 3000)
                self.draw_graph()

    def search_node(self):
        """根据搜索框中输入的节点名称，定位并高亮目标节点"""
        node_id = self.search_box.text().strip()
        if not node_id:
            return

        if node_id in self.graph.nodes:
            self.highlight_node = node_id
            if hasattr(self, 'statusBar'):
                self.statusBar().showMessage(f"已找到节点 {node_id}", 3000)

            # ===== 高亮表格中对应行 =====
            self.table.setCurrentItem(None)  # 清除当前选中项
            for row in range(self.table.rowCount()):
                if self.table.item(row, 0) and self.table.item(row, 0).text() == node_id:
                    self.table.selectRow(row)
                    self.table.scrollToItem(self.table.item(row, 0), QTableWidget.PositionAtCenter)
                    break
        else:
            self.highlight_node = None
            self.table.clearSelection()  # 未找到时取消表格选择
            if hasattr(self, 'statusBar'):
                self.statusBar().showMessage(f"未找到节点 {node_id}", 3000)

        self.draw_graph()

    """将图中的所有节点信息填充至右侧属性表格中"""
    def populate_node_table(self):
        self.table.setRowCount(0)
        self.table.verticalHeader().setVisible(False)  # 隐藏行号
        nodes = sorted(self.graph.nodes, key=lambda x: int(x))

        for node in nodes:
            node_str = str(node)
            node_name = self.id_to_name.get(node_str, "")

            # 找到以当前节点为目标（被指向）的所有节点 → 父节点
            predecessors = [str(src) for src, dst in self.graph.edges if dst == node_str]

            # 找到以当前节点为起点（指向他人）的所有节点 → 子节点
            successors = [str(dst) for src, dst in self.graph.edges if src == node_str]

            row = self.table.rowCount()
            self.table.insertRow(row)
            self.table.setItem(row, 0, QTableWidgetItem(node_str))  # 序号（节点编号）
            self.table.setItem(row, 1, QTableWidgetItem(str(node_name)))  # 节点名称
            self.table.setItem(row, 2, QTableWidgetItem(";".join(sorted(predecessors, key=int))))  # 父节点
            self.table.setItem(row, 3, QTableWidgetItem(";".join(sorted(successors, key=int))))  # 子节点

    """将当前 QGraphicsScene 中绘制的图结构导出为 PNG 图像并保存到本地"""
    def save_graph_as_png(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "保存图为 PNG", "", "PNG Files (*.png)")
        if not file_path:
            return

        # 创建与视图大小相同的图像对象
        image = QImage(self.view.viewport().size(), QImage.Format_ARGB32)
        image.fill(Qt.white)  # 可选：设置背景为透明或白色
        painter = QPainter(image)
        self.view.render(painter)
        painter.end()

        # 保存图像
        image.save(file_path)
        QMessageBox.information(self, "保存成功", f"图已保存为图片：\n{file_path}")

    def apply_community_coloring(self):
        if not self.graph or self.graph.number_of_nodes() == 0:
            return

        method = self.module_algo_combo.currentText()
        self.module_spinbox.value()

        if method == "label_propagation":
            communities = list(label_propagation_communities(self.graph))
        elif method == "louvain":
            communities = list(louvain_communities(self.graph))
        elif method == "greedy":
            communities = list(greedy_modularity_communities(self.graph))
        else:
            return

        self.communities_dict = {}
        for i, community in enumerate(communities):
            for node in community:
                self.communities_dict[node] = i

        cmap = plt.get_cmap("tab10")
        for node, module in self.communities_dict.items():
            color = cmap(module % 10)
            rgb_color = QColor(int(color[0] * 255), int(color[1] * 255), int(color[2] * 255))
            self.graph.nodes[node]["color"] = rgb_color

        self.draw_graph()

    def apply_greedy_community_coloring(self):
        """应用贪婪模块度算法"""
        communities = list(greedy_modularity_communities(self.graph))
        self.color_communities(communities)
        self.apply_community_layout(communities)

    def apply_label_propagation_coloring(self):
        """应用标签传播算法"""
        communities = list(label_propagation_communities(self.graph))
        self.color_communities(communities)
        self.apply_community_layout(communities)

    def apply_louvain_coloring(self, n_modules):
        """应用Louvain算法进行社区发现并着色"""
        try:
            # 方法1: 使用python-louvain包 (推荐)
            try:
                import community as louvain_community
                partition = louvain_community.best_partition(self.graph)
                communities_dict = {}
                for node, comm_id in partition.items():
                    communities_dict.setdefault(comm_id, []).append(node)
                communities = list(communities_dict.values())
            except ImportError:
                # 方法2: 使用networkx内置的Louvain实现
                communities = list(louvain_communities(self.graph))

            # 确保社区数量不超过指定的模块数
            if n_modules and len(communities) > n_modules:
                communities = sorted(communities, key=len, reverse=True)[:n_modules]

            self.color_communities(communities)
            self.apply_community_layout(communities)

        except Exception as e:
            QMessageBox.critical(self, "Louvain算法错误",
                                 f"社区划分失败:\n{str(e)}\n\n"
                                 "建议安装python-louvain包:\n"
                                 "pip install python-louvain")
            self.statusBar().showMessage("Louvain算法执行失败", 3000)

    def color_communities(self, communities):
        """为社区分配颜色，兼容多种社区格式"""
        if not communities:
            return

        if isinstance(communities, dict):
            communities = list(communities.values())
        if isinstance(next(iter(communities)), frozenset):
            communities = [list(c) for c in communities]

        color_palette = [
            QColor(31, 119, 180), QColor(255, 127, 14),
            QColor(44, 160, 44), QColor(214, 39, 40),
            QColor(148, 103, 189), QColor(140, 86, 75),
            QColor(227, 119, 194), QColor(127, 127, 127),
            QColor(188, 189, 34), QColor(23, 190, 207)
        ]

        self.node_communities = {}
        self.communities_dict = {}  # 新增

        for i, comm in enumerate(communities):
            color = color_palette[i % len(color_palette)]
            for node in comm:
                self.graph.nodes[node]['color'] = color
                self.graph.nodes[node]['community'] = i
                self.node_communities[node] = i
                self.communities_dict[node] = i  # 新增：为绘图服务

        self.communities = communities  # 原始结构保留
        self.draw_graph()

    def apply_community_layout(self, communities):
        """应用社区优化布局"""
        # 自动选择适合社区可视化的布局
        if not hasattr(self, 'last_layout') or self.last_layout != "Circular":
            self.layout_combo.setCurrentText("Circular")
            self.last_layout = "Circular"

        # 强制重新计算布局
        self.cached_pos = None
        self.draw_graph()

    # 去除模块化
    def clear_communities(self):
        if self.graph:
            for node in self.graph.nodes():
                self.graph.nodes[node].pop("color", None)
            self.communities_dict = {}
            self.draw_graph()

    def on_module_algo_changed(self, algo_name):
        if algo_name == "greedy":
            self.module_spinbox.setEnabled(False)
        else:
            self.module_spinbox.setEnabled(True)

    def clear_highlight(self):
        """清除高亮状态"""
        self.highlight_node = None
        self.table.clearSelection()
        self.draw_graph()

    def setup_fonts(self):
        """设置粗体字体"""
        self.bold_font = QFont()
        self.bold_font.setBold(True)
        self.bold_font.setPointSize(9)  # 可以根据需要调整字体大小

        # 设置节点标签字体（稍大一些）
        self.label_font = QFont()
        self.label_font.setBold(True)
        self.label_font.setPointSize(18)

# 启动程序入口
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = GraphVisualizer()
    window.resize(1200, 700)
    window.show()
    sys.exit(app.exec_())
