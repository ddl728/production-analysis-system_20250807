# import pandas as pd
# from pyvis.network import Network
#
#
# def create_network_from_adjacency(csv_path):
#     df = pd.read_csv(csv_path, index_col=0)
#     df.columns = df.columns.map(str)
#     df.index = df.index.map(str)
#
#     net = Network(directed=True)
#     for node in df.index:
#         net.add_node(node, label=node)
#     for source in df.index:
#         for target in df.columns:
#             if df.loc[source, target] != 0:
#                 net.add_edge(source, target, value=df.loc[source, target])
#     return net
#
#
#
# def apply_default_layout(net: Network):
#     """
#     默认力导向布局（pyvis 默认使用 vis.js 的 forceAtlas2Based）
#     """
#     net.force_atlas_2based()
#     return net
#
#
# def apply_hierarchical_layout(net: Network):
#     """
#     层次布局：常用于树形或流程结构
#     """
#     net.set_options("""
#     var options = {
#       layout: {
#         hierarchical: {
#           enabled: true,
#           direction: "UD",  // UD=上下, LR=左右
#           sortMethod: "hubsize"
#         }
#       }
#     }
#     """)
#     return net
#
#
# def apply_random_layout(net: Network):
#     """
#     随机布局（不设置 forceAtlas）
#     """
#     net.toggle_physics(False)
#     return net
#
#
# def apply_physics_layout(net: Network):
#     """
#     启用物理模拟的动态力导向布局
#     """
#     net.set_options("""
#     var options = {
#       physics: {
#         enabled: true,
#         solver: "forceAtlas2Based",
#         forceAtlas2Based: {
#           gravitationalConstant: -50,
#           centralGravity: 0.01,
#           springLength: 100,
#           springConstant: 0.08,
#           damping: 0.4,
#           avoidOverlap: 0
#         },
#         stabilization: {
#           enabled: true,
#           iterations: 1000
#         }
#       }
#     }
#     """)
#     return net
#
# def apply_circle_layout(net: Network):
#     import math
#     nodes = [node['id'] for node in net.nodes]  # 获取所有节点 id
#     n = len(nodes)
#     radius = 300
#     angle_step = 2 * math.pi / n
#
#     new_net = Network(height=net.height, width=net.width, directed=net.directed)
#
#     # 复制节点 + 设定坐标
#     for i, node_id in enumerate(nodes):
#         x = radius * math.cos(i * angle_step)
#         y = radius * math.sin(i * angle_step)
#         new_net.add_node(node_id, label=node_id, x=x, y=y, fixed=True)
#
#     # 复制边
#     for edge in net.edges:
#         new_net.add_edge(edge['from'], edge['to'], value=edge.get('value', 1))
#
#     new_net.toggle_physics(False)
#     return new_net
#
#
from pyvis.network import Network
import pandas as pd
import math


def build_network_from_csv(path_to_csv):
    """
    从邻接矩阵 CSV 文件创建一个 PyVis 有向网络图。
    """
    adjacency = pd.read_csv(path_to_csv, index_col=0)
    adjacency.columns = adjacency.columns.astype(str)
    adjacency.index = adjacency.index.astype(str)

    net = Network(directed=True)

    # 添加节点
    for node_id in adjacency.index:
        net.add_node(node_id, label=node_id)

    # 添加边
    for src in adjacency.index:
        for dst in adjacency.columns:
            weight = adjacency.loc[src, dst]
            if weight != 0:
                net.add_edge(src, dst, value=weight)

    return net


def layout_default_force(net: Network):
    """
    应用默认的 forceAtlas2Based 力导向布局。
    """
    net.force_atlas_2based()
    return net


def layout_hierarchical_view(net: Network):
    """
    应用分层布局，适合展示流程图、树结构。
    """
    net.set_options("""
    var options = {
      layout: {
        hierarchical: {
          enabled: true,
          direction: "UD",
          sortMethod: "hubsize"
        }
      }
    }
    """)
    return net


def layout_static_random(net: Network):
    """
    设置为随机布局，并关闭物理模拟。
    """
    net.toggle_physics(False)
    return net


def layout_with_physics_simulation(net: Network):
    """
    应用自定义物理模拟参数的力导向布局。
    """
    net.set_options("""
    var options = {
      physics: {
        enabled: true,
        solver: "forceAtlas2Based",
        forceAtlas2Based: {
          gravitationalConstant: -50,
          centralGravity: 0.01,
          springLength: 100,
          springConstant: 0.08,
          damping: 0.4,
          avoidOverlap: 0
        },
        stabilization: {
          enabled: true,
          iterations: 1000
        }
      }
    }
    """)
    return net


def layout_nodes_in_circle(net: Network, radius=300):
    """
    以圆形布局方式手动设置所有节点位置，并关闭物理模拟。
    """
    node_ids = [n['id'] for n in net.nodes]
    num_nodes = len(node_ids)
    angle_gap = 2 * math.pi / max(num_nodes, 1)

    arranged_net = Network(height=net.height, width=net.width, directed=net.directed)

    for idx, node_id in enumerate(node_ids):
        angle = idx * angle_gap
        x = radius * math.cos(angle)
        y = radius * math.sin(angle)
        arranged_net.add_node(node_id, label=node_id, x=x, y=y, fixed=True)

    for edge in net.edges:
        arranged_net.add_edge(edge['from'], edge['to'], value=edge.get('value', 1))

    arranged_net.toggle_physics(False)
    return arranged_net

