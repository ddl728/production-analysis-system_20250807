# graph_viewer.py
import csv
import os
import tempfile

import networkx as nx
from PyQt5.QtCore import QUrl
from PyQt5.QtGui import QColor
from PyQt5.QtWebEngineWidgets import QWebEngineView
from PyQt5.QtWidgets import (
    QMainWindow, QFileDialog, QWidget, QVBoxLayout, QHBoxLayout,
    QPushButton, QLabel, QColorDialog, QSpinBox, QComboBox, QMessageBox
)
from pyvis.network import Network


class GraphViewer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("生产线参数关联分析系统")
        self.resize(1200, 800)

        self.graph = None
        self.id_to_name = {}
        self.name_to_id = {}

        self.node_color = QColor("deepskyblue")
        self.edge_color = QColor("gray")
        self.node_size = 20
        self.layout_type = "spring"

        self.init_ui()

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QHBoxLayout()
        central_widget.setLayout(main_layout)

        # 左侧控制区域
        control_panel = QVBoxLayout()

        import_button = QPushButton("导入 CSV")
        import_button.clicked.connect(self.load_csv)
        control_panel.addWidget(import_button)

        color_button = QPushButton("选择节点颜色")
        color_button.clicked.connect(self.choose_node_color)
        control_panel.addWidget(color_button)

        size_label = QLabel("节点大小：")
        self.size_spin = QSpinBox()
        self.size_spin.setRange(10, 100)
        self.size_spin.setValue(self.node_size)
        self.size_spin.valueChanged.connect(self.update_node_size)
        control_panel.addWidget(size_label)
        control_panel.addWidget(self.size_spin)

        layout_label = QLabel("布局类型：")
        self.layout_combo = QComboBox()
        self.layout_combo.addItems(["spring", "kamada_kawai", "circular"])
        self.layout_combo.currentTextChanged.connect(self.update_layout)
        control_panel.addWidget(layout_label)
        control_panel.addWidget(self.layout_combo)

        control_panel.addStretch()
        main_layout.addLayout(control_panel, 1)

        # 右侧显示区域
        right_layout = QVBoxLayout()

        self.web_view = QWebEngineView()
        right_layout.addWidget(QLabel("PyVis 可视化布局："))
        right_layout.addWidget(self.web_view)

        main_layout.addLayout(right_layout, 4)

    def load_csv(self):
        path, _ = QFileDialog.getOpenFileName(self, "选择 CSV 文件", "", "CSV Files (*.csv)")
        if not path:
            return

        try:
            with open(path, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                edges = []
                self.id_to_name = {}
                self.name_to_id = {}
                for row in reader:
                    src = row["source"]
                    tgt = row["target"]
                    label = row.get("label", "")
                    self.id_to_name[src] = label or src
                    self.id_to_name[tgt] = tgt  # fallback
                    edges.append((src, tgt))
                self.graph = nx.DiGraph()
                self.graph.add_edges_from(edges)
                self.draw_pyvis_graph()
        except Exception as e:
            QMessageBox.critical(self, "错误", f"导入 CSV 失败：{e}")

    def choose_node_color(self):
        color = QColorDialog.getColor()
        if color.isValid():
            self.node_color = color
            self.draw_pyvis_graph()

    def update_node_size(self, value):
        self.node_size = value
        self.draw_pyvis_graph()

    def update_layout(self, layout):
        self.layout_type = layout
        self.draw_pyvis_graph()

    def draw_pyvis_graph(self):
        if self.graph is None:
            return

        net = Network(height="600px", width="100%", directed=True)
        net.barnes_hut()  # 开启力导布局（可选）

        for node in self.graph.nodes:
            label = self.id_to_name.get(str(node), str(node))
            net.add_node(str(node), label=label, color=self.node_color.name(), size=self.node_size)

        for u, v in self.graph.edges:
            net.add_edge(str(u), str(v), color=self.edge_color.name())

        tmp_path = os.path.join(tempfile.gettempdir(), "pyvis_graph.html")
        net.show(tmp_path)
        self.web_view.load(QUrl.fromLocalFile(tmp_path))
