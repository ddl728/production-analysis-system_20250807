import pandas as pd

# 读取 Excel 文件的第一列（默认读取第一个工作表）
df = pd.read_excel('label_matrix.xlsx', header=None)  # 如果无表头

# 获取第一列所有值，转换为字符串并去除空值（可选）
new_list = df.iloc[:, 0].dropna().astype(str).tolist()

for i in new_list:
    print("'" + i + "'" + ", ")
