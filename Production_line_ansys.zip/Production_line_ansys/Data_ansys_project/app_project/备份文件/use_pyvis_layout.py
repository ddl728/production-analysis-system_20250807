from Data_ansys_project.app_project.备份文件.pyvis_layout import (
    build_network_from_csv,
    layout_nodes_in_circle
)

# 读取图
net = build_network_from_csv("../../test_csv/english_indx.csv")

# 应用某种布局
net = layout_nodes_in_circle(net)  # 或者 apply_hierarchical_layout(net)

# 显示最终布局图
net.show("network.html")
