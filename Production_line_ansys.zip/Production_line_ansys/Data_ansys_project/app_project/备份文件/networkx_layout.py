# import matplotlib.pyplot as plt
# import networkx as nx
#
#
# def community_layout(g, partition):
#     pos_communities = position_communities(g, partition, scale=3.)
#
#     pos_nodes = position_nodes(g, partition, scale=1.)
#
#     # combine positions
#     pos = dict()
#     for node in g.nodes():
#         pos[node] = pos_communities[node] + pos_nodes[node]
#     return pos
#
#
# def position_communities(g, partition, **kwargs):
#     # create a weighted graph, in which each node corresponds to a community,
#     # and each edge weight to the number of edges between communities
#     between_community_edges = find_between_community_edges(g, partition)
#
#     communities = set(partition.values())
#     hypergraph = nx.DiGraph()
#     hypergraph.add_nodes_from(communities)
#     for (ci, cj), edges in between_community_edges.items():
#         hypergraph.add_edge(ci, cj, weight=len(edges))
#
#     # find layout for communities
#     pos_communities = nx.spring_layout(hypergraph, **kwargs)
#
#     # set node positions to position of community
#     pos = dict()
#     for node, community in partition.items():
#         pos[node] = pos_communities[community]
#
#     return pos
#
#
# def find_between_community_edges(g, partition):
#     edges = dict()
#
#     for (ni, nj) in g.edges():
#         ci = partition[ni]
#         cj = partition[nj]
#
#         if ci != cj:
#             try:
#                 edges[(ci, cj)] += [(ni, nj)]
#             except KeyError:
#                 edges[(ci, cj)] = [(ni, nj)]
#
#     return edges
#
#
# def position_nodes(g, partition, **kwargs):
#     """
#     Positions nodes within communities.
#     """
#
#     communities = dict()
#     for node, community in partition.items():
#         try:
#             communities[community] += [node]
#         except KeyError:
#             communities[community] = [node]
#
#     pos = dict()
#     for ci, nodes in communities.items():
#         subgraph = g.subgraph(nodes)
#         pos_subgraph = nx.spring_layout(subgraph, **kwargs)
#         pos.update(pos_subgraph)
#
#     return pos
#
#
# def test():
#     from community import community_louvain
#     g = nx.karate_club_graph()
#     partition = community_louvain.best_partition(g)
#     pos = community_layout(g, partition)
#
#     nx.draw(g, pos, node_color=list(partition.values()))
#     plt.show()
#     return
import matplotlib.pyplot as plt
import networkx as nx
from collections import defaultdict


def modular_layout(graph, community_map):
    """
    返回模块化布局坐标，结合社区中心布局和社区内节点布局。
    """
    cluster_centers = _compute_community_positions(graph, community_map, scale=3.0)
    internal_offsets = _compute_internal_positions(graph, community_map, scale=1.0)

    final_pos = {
        node: cluster_centers[node] + internal_offsets[node]
        for node in graph.nodes()
    }
    return final_pos


def _compute_community_positions(graph, community_map, **layout_kwargs):
    """
    将每个社区视为一个节点，基于社区之间的连接关系构造超图，并计算社区中心位置。
    """
    community_edges = _extract_inter_community_edges(graph, community_map)

    all_communities = set(community_map.values())
    community_graph = nx.Graph()
    community_graph.add_nodes_from(all_communities)

    for (com1, com2), edge_list in community_edges.items():
        community_graph.add_edge(com1, com2, weight=len(edge_list))

    community_centers = nx.spring_layout(community_graph, **layout_kwargs)

    node_positions = {
        node: community_centers[community_map[node]]
        for node in graph.nodes()
    }
    return node_positions


def _extract_inter_community_edges(graph, community_map):
    """
    获取连接不同社区之间的边集合。
    返回字典：(com_i, com_j) -> [edge1, edge2, ...]
    """
    edge_dict = defaultdict(list)
    for u, v in graph.edges():
        cu, cv = community_map[u], community_map[v]
        if cu != cv:
            edge_dict[(cu, cv)].append((u, v))
    return edge_dict


def _compute_internal_positions(graph, community_map, **layout_kwargs):
    """
    在每个社区内部对节点进行布局。
    """
    # 社区编号 → 节点列表
    communities = defaultdict(list)
    for node, com_id in community_map.items():
        communities[com_id].append(node)

    internal_positions = {}
    for com_id, node_list in communities.items():
        sub_g = graph.subgraph(node_list)
        local_pos = nx.spring_layout(sub_g, **layout_kwargs)
        internal_positions.update(local_pos)

    return internal_positions


def demo():
    """
    示例：对 Karate Club 图进行社区划分并可视化模块化布局
    """
    from community import community_louvain

    G = nx.karate_club_graph()
    partition = community_louvain.best_partition(G)

    pos = modular_layout(G, partition)
    nx.draw(
        G, pos,
        node_color=list(partition.values()),
        with_labels=True,
        node_size=300,
        cmap=plt.cm.Set3
    )
    plt.title("Modular Graph Layout")
    plt.show()
