import matplotlib.pyplot as plt
import networkx as nx
import numpy as np
import pandas as pd
from PyQt5 import QtWidgets


class GraphVisualizer(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("图形可视化")
        self.setGeometry(100, 100, 800, 600)

        # 创建按钮，用来加载CSV文件
        self.load_button = QtWidgets.QPushButton("加载CSV文件", self)
        self.load_button.clicked.connect(self.load_csv)
        self.load_button.setGeometry(10, 10, 120, 40)

    def load_csv(self):
        # 打开文件对话框，选择 CSV 文件
        options = QtWidgets.QFileDialog.Options()
        file_path, _ = QtWidgets.QFileDialog.getOpenFileName(self, "选择CSV文件", "", "CSV Files (*.csv)",
                                                             options=options)
        if file_path:
            self.create_graph_from_csv(file_path)

    def create_graph_from_csv(self, file_path):
        # 读取 CSV 文件，假设它包含两列 'source' 和 'target'，表示边
        df = pd.read_csv(file_path)

        # 创建一个空的图对象
        G = nx.Graph()

        # 根据 CSV 数据添加节点和边
        for _, row in df.iterrows():
            G.add_edge(row['source'], row['target'])

        # 设置 shell 布局并绘制图形
        self.plot_shell_layout(G)

    def plot_shell_layout(self, G):
        # 计算节点的层次，这里我们手动设置分层，可以根据节点的度数或其他属性设置
        shells = self.get_shells(G)

        # 使用 shell 布局算法绘制节点
        pos = self.shell_layout(G, shells)

        # 绘制图
        plt.figure(figsize=(8, 8))
        nx.draw(G, pos, with_labels=True, node_size=500, node_color='skyblue', font_size=10, font_weight='bold',
                edge_color='gray')
        plt.title("Shell 布局图")
        plt.show()

    def get_shells(self, G):
        # 假设这里我们按度数来划分层
        # 在实际应用中，可以根据其他逻辑来分层
        shells = {}
        for node, degree in G.degree():
            # 假设度数相同的节点放在同一层，这里使用度数为层的标识
            shells.setdefault(degree, []).append(node)
        # 返回按层划分的节点列表
        return [shells[k] for k in sorted(shells.keys())]

    def shell_layout(self, G, shells):
        pos = {}
        # 每个节点占据一个等分角度
        angle_step = 360 / len(G.nodes())
        for i, shell in enumerate(shells):
            radius = (i + 1) * 2
            for j, node in enumerate(shell):
                angle = j * angle_step
                x = radius * np.cos(np.radians(angle))
                y = radius * np.sin(np.radians(angle))
                pos[node] = (x, y)
        return pos

if __name__ == '__main__':
    app = QtWidgets.QApplication([])
    window = GraphVisualizer()
    window.show()
    app.exec_()
