# 使用 NetworkX 的 dfs_successors、shortest_path 或自定义搜索获取路径：
def get_influence_paths(G, start_node, max_depth=3):
    paths = []

    def dfs(node, path, depth):
        if depth > max_depth:
            return
        for neighbor in G.successors(node):  # 有向图
            new_path = path + [neighbor]
            paths.append(new_path)
            dfs(neighbor, new_path, depth + 1)

    dfs(start_node, [start_node], 0)
    return paths

from PyQt5.QtCore import QTimer
import networkx as nx


def animate_path(canvas, G, pos, node_path, edge_path, original_node_colors, original_edge_colors):
    step = 0
    timer = QTimer()

    def highlight_step():
        nonlocal step
        if step >= len(node_path):
            timer.stop()
            return

        node = node_path[step]
        nx.draw_networkx_nodes(G, pos, nodelist=[node], node_color='red', ax=canvas.ax)

        if step > 0:
            edge = edge_path[step - 1]
            nx.draw_networkx_edges(G, pos, edgelist=[edge], edge_color='red', width=3, ax=canvas.ax)

        canvas.draw()
        step += 1

    # 清空之前的绘图，重绘基础图
    canvas.ax.clear()
    nx.draw(G, pos, with_labels=True, ax=canvas.ax, node_color=original_node_colors, edge_color=original_edge_colors)
    canvas.draw()

    timer.timeout.connect(highlight_step)
    timer.start(500)


def on_node_clicked(node_id):
    paths = get_influence_paths(G, node_id, max_depth=3)
    if not paths:
        print("No downstream path found.")
        return

    path = paths[0]  # 演示第一条路径
    edge_path = list(zip(path[:-1], path[1:]))

    # 原始样式（以白色节点和灰色边为例）
    original_node_colors = ['white' for _ in G.nodes]
    original_edge_colors = ['gray' for _ in G.edges]

    animate_path(canvas, G, pos, path, edge_path, original_node_colors, original_edge_colors)
