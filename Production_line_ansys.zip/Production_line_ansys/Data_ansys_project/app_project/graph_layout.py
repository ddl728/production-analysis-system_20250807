# graph_layouts.py
import networkx as nx


# 同心圆环型布局
def shell_layout(G):
    nodes = list(G.nodes())
    if len(nodes) < 3:
        pos = nx.shell_layout(G)
    else:
        # 将节点分成 3 层，每层大小尽量平均且无重复
        num_layers = 3
        layer_size = len(nodes) // num_layers
        shell_layers = [nodes[i * layer_size: (i + 1) * layer_size] for i in range(num_layers - 1)]
        # 最后一层放剩余节点
        shell_layers.append(nodes[(num_layers - 1) * layer_size:])
        # 过滤空层
        shell_layers = [layer for layer in shell_layers if layer]
        pos = nx.shell_layout(G, nlist=shell_layers)
    return pos


# 同心圆环型，类似靶子
def concentric_layout(G, node_size=0.1):
    import math
    pos = {}
    nodes = list(G.nodes())
    if not nodes:
        return pos
    # 节点半径（可调节）
    node_radius = math.sqrt(node_size) / 2
    # 每圈最多节点数（可调节）
    max_nodes_per_circle = 13
    index = 0
    layer = 0

    while index < len(nodes):
        # 每圈的节点数，逐圈增加
        num_nodes_in_layer = min(len(nodes) - index, max_nodes_per_circle + layer * 4)
        # 圈之间的距离 = 节点大小的倍数
        radius = (layer + 1) * node_radius
        angle_step = 2 * math.pi / num_nodes_in_layer

        for i in range(num_nodes_in_layer):
            angle = i * angle_step
            x = radius * math.cos(angle)
            y = radius * math.sin(angle)
            pos[nodes[index]] = (x, y)
            index += 1
            if index >= len(nodes):
                break
        layer += 1

    return pos
