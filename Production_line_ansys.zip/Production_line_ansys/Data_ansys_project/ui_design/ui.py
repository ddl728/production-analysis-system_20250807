# 基于用户提供的界面图，设计符合其布局的 PyQt5 软件架构

import sys
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QLabel, QPushButton, QVBoxLayout, QHBoxLayout, QGridLayout,
    QCheckBox, QComboBox, QFileDialog, QTableWidget, QTableWidgetItem, QLineEdit, QFrame
)
from PyQt5.QtGui import QFont, QColor, QIcon
from PyQt5.QtCore import Qt


class CustomGraphUI(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("参数关系可视化软件")
        self.setGeometry(100, 100, 1200, 700)
        self.init_ui()

    def init_ui(self):
        # 左侧控制区域
        control_panel = QVBoxLayout()
        control_panel.setSpacing(10)

        # 文件导入按钮
        import_btn = QPushButton("文件导入")
        control_panel.addWidget(import_btn)

        # 节点设置
        control_panel.addWidget(QLabel("节点"))
        node_shape_btn = QPushButton("节点形状")
        node_size_btn = QPushButton("节点大小")
        node_color_btn = QPushButton("节点颜色")
        control_panel.addWidget(node_shape_btn)
        control_panel.addWidget(node_size_btn)
        control_panel.addWidget(node_color_btn)

        # 边设置
        control_panel.addWidget(QLabel("边"))
        edge_style_btn = QPushButton("边样式")
        edge_thickness_btn = QPushButton("边粗细")
        edge_color_btn = QPushButton("边颜色")
        control_panel.addWidget(edge_style_btn)
        control_panel.addWidget(edge_thickness_btn)
        control_panel.addWidget(edge_color_btn)

        # 布局方式
        control_panel.addWidget(QLabel("布局方式"))
        layout_buttons = ["经典的分层", "花瓣形", "星形", "轮形", "烟花形"]
        for name in layout_buttons:
            layout_btn = QPushButton(name)
            control_panel.addWidget(layout_btn)

        readme_btn = QPushButton("参考README")
        control_panel.addWidget(readme_btn)

        # 复选框
        label_checkbox = QCheckBox("显示节点标签")
        weight_checkbox = QCheckBox("显示边权重")
        label_checkbox.setChecked(True)
        weight_checkbox.setChecked(True)
        control_panel.addWidget(label_checkbox)
        control_panel.addWidget(weight_checkbox)

        # 底部按钮
        run_btn = QPushButton("运行")
        export_btn = QPushButton("导出结果")
        control_panel.addWidget(run_btn)
        control_panel.addWidget(export_btn)

        control_widget = QWidget()
        control_widget.setLayout(control_panel)
        control_widget.setFixedWidth(200)

        # 中间绘图区域
        canvas = QLabel("参数关系可视化")
        canvas.setAlignment(Qt.AlignCenter)
        canvas.setFrameShape(QFrame.Box)

        # 右侧结果分析
        analysis_layout = QVBoxLayout()
        analysis_layout.addWidget(QLabel("结果分析"))

        node_label = QLabel("节点：")
        edge_label = QLabel("边：")
        node_input = QLineEdit()
        edge_input = QLineEdit()

        search_layout = QHBoxLayout()
        search_input = QLineEdit()
        search_input.setPlaceholderText("Search:")
        search_layout.addWidget(search_input)

        analysis_layout.addLayout(search_layout)
        analysis_layout.addWidget(node_label)
        analysis_layout.addWidget(node_input)
        analysis_layout.addWidget(edge_label)
        analysis_layout.addWidget(edge_input)

        table = QTableWidget(0, 4)
        table.setHorizontalHeaderLabels(["序号", "节点名称", "父节点序号", "子节点序号"])
        analysis_layout.addWidget(table)

        analysis_widget = QWidget()
        analysis_widget.setLayout(analysis_layout)
        analysis_widget.setFixedWidth(300)

        # 主布局
        main_layout = QHBoxLayout()
        main_layout.addWidget(control_widget)
        main_layout.addWidget(canvas, stretch=2)
        main_layout.addWidget(analysis_widget)

        container = QWidget()
        container.setLayout(main_layout)
        self.setCentralWidget(container)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = CustomGraphUI()
    window.show()
    sys.exit(app.exec_())
